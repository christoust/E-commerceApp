// import './App.css';
import MainApp from './Components/Main/Main';

function App() {
  return (

    <MainApp/>
  );
}

export default App;

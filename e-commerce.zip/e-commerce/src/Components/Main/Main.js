// MainApp.js
import React from 'react';
import ProductList from '../Product-List/ProductList';


const MainApp = () => {
  return (
    <div className="App">
      <h1 className='title'>Fresh Harvest</h1>
      <ProductList />
    </div>
  );
};

export default MainApp;

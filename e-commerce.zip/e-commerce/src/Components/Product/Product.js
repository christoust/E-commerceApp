// Product.js
import React, { useState } from "react";
import "./Product.css";

const Product = ({ title, type, description, url, price, rating }) => {
  const [like, setLiked] = useState(0);
  const [shared, setShared] = useState(false);
  const [purchased, setPurchased] = useState(false);

  const handleLike = () => {
    setLiked(!like);
  };

  const handlePurchase = () => {
    setPurchased(true);
    alert(`Thank you for purchasing ${title}`); // Toggle the purchased state
  };

  const handleShare = () => {
    setShared(true); // Toggle the shared state
    alert(`Thank you for sharing ${title}`);
  };

  return (
    <div className="card">
      <img src={url} alt={title} />
      <h3>{title}</h3>
      <p className="description">{description}</p>
      <p>Type: {type}</p>
      <p>Price: ${price}</p>
      <p>Rating: {rating}</p>
      <div className="buttons">
        <button
          onClick={handleLike}
          style={{
            backgroundColor: like ? "blue" : "",
            color: like ? "white" : "",
          }}
        >
          {like ? "Liked" : "Like"}{" "}
        </button>
        <button
          onClick={handleShare}
          disabled={shared}
          style={{
            backgroundColor: shared ? "blue" : "",
            color: shared ? "white" : "",
          }}
        >
          {shared ? "Shared" : "Share"}
        </button>
        <button
          onClick={handlePurchase}
          disabled={purchased}
          style={{
            backgroundColor: purchased ? "blue" : "",
            color: purchased ? "white" : "",
          }}
        >
          {purchased ? "Purchased" : "Purchase"}
        </button>
      </div>
    </div>
  );
};

export default Product;
